package com.HMS.HMS.Project.Session;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HmsProjectSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
