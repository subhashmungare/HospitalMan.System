package com.HMS.HMS.Project.Session;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmsProjectSessionApplication {

	public static void main(String[] args) {
		SpringApplication.run(HmsProjectSessionApplication.class, args);
		System.out.println("HMS Projects Runninnnnggg....");
	}

}
